Livestock optimizer stage outputs.
IMPORTANT: ration ingredient values, prices, inventory, demand, lead times, and order sizes are synthetic illustrative assumptions. These outputs are not real cattle-feeding advice.
The market CSV is a one-day snapshot and has not been automatically merged to nutrient data.
Validate feed identities, nutrient units, price units, Indian cattle requirements, and supplier data before operational use.
