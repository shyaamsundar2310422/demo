# Dataset prep — first pass

## Files
- `feed_nutrients_clean_long.csv`: cleaned ERA Feed Library Mean.csv in long format.
- `feed_nutrients_clean_wide.csv`: one row per feed item and source country, nutrient codes pivoted to columns.
- `market_prices_feed_candidates.csv`: selected market-price rows for candidate feed-related commodities.
- `ingredient_crosswalk_review_required.csv`: cautious proposed mappings; human review required.
- `raw_era/`: original files from the uploaded ERA Feed Library ZIP.

## Important limitations
1. ERA Feed Library metadata says geographic coverage is African countries. Do not assume its values are representative of Indian feed resources.
2. The uploaded mandi CSV has 8,443 rows, but every row has arrival date 18/10/2026. It is a one-day snapshot, not historical data for price forecasting.
3. Market prices have been kept in the source's original price units. Confirm the source metadata and price unit before converting or using the values in a model.
4. Commodity names are not automatically interchangeable with feed items. For example, a price for wheat grain cannot be assigned to wheat bran, and a groundnut price cannot be assigned to groundnut cake.
5. Feed nutrient codes/units are preserved from the ERA Mean file. Use the dictionary and data paper to interpret codes and standardized units before optimization.
6. The files have not been merged into one flat training table because their keys and meanings differ. They should be linked through a reviewed ingredient crosswalk and then assembled per planning date.
