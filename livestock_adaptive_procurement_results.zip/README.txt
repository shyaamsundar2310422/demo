
LIVESTOCK ADAPTIVE PROCUREMENT OPTIMIZER - RESULTS
==================================================
These results are from a synthetic operational simulation.

Files:
- synthetic_ingredient_assumptions.csv: illustrative demand, stock, prices, lead times
- adaptive_procurement_daily_results.csv: daily stock and unmet-demand records
- adaptive_procurement_orders.csv: simulated order placements and costs
- adaptive_procurement_summary.csv: policy metrics by scenario
- fixed_vs_adaptive_comparison.csv: direct policy comparison

Scenarios:
- baseline: no price shock or lead-time delay
- price_shock: 20% price increase
- supplier_delay: 3 extra delivery days
- combined_disruption: both changes

Policy:
- fixed: reorder point uses normal lead time and fixed safety stock
- adaptive: increases reorder point and target stock during delayed-supply scenarios

Limitations:
- All ingredient demand, starting inventory, prices, and lead times are synthetic.
- This is inventory/procurement simulation, not a validated cattle feed formulation.
- No actual supplier quotes, farm inventory logs, or historical delivery records were used.
- Outcomes depend on assumptions and policy settings; they do not establish real-world performance.
