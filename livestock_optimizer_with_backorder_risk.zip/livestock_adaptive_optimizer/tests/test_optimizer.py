from pathlib import Path
import pandas as pd
from src.optimizer import OptimizationConfig, optimize_feed_plan
ROOT = Path(__file__).resolve().parents[1]
ingredients = pd.read_csv(ROOT / "data" / "feed_ingredients.csv")
suppliers = pd.read_csv(ROOT / "data" / "suppliers.csv")
def test_optimizer_finds_feasible_plan():
    result = optimize_feed_plan(ingredients, suppliers, OptimizationConfig(total_ration_kg=10, min_crude_protein_kg=1.2, min_energy_mj=100))
    assert result["success"]
    assert abs(result["metrics"]["total_quantity_kg"] - 10) < 1e-5
    assert result["metrics"]["protein_constraint_met"] and result["metrics"]["energy_constraint_met"]
def test_supplier_outage_can_be_simulated():
    result = optimize_feed_plan(ingredients, suppliers, OptimizationConfig(total_ration_kg=10, min_crude_protein_kg=1.2, min_energy_mj=100, unavailable_supplier_ids=("S1",)))
    assert result["success"]
    assert "S1" not in set(result["plan"].supplier_id)
def test_all_suppliers_unavailable_returns_failure():
    result = optimize_feed_plan(ingredients, suppliers, OptimizationConfig(unavailable_supplier_ids=("S1", "S2", "S3")))
    assert not result["success"]
