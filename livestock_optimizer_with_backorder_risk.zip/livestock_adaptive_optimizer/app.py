from pathlib import Path
import warnings
import joblib
import numpy as np
import pandas as pd
import streamlit as st
from src.optimizer import OptimizationConfig, optimize_feed_plan

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "tuned_backorder_risk_model.joblib"

st.set_page_config(page_title="Livestock Adaptive Optimizer", page_icon="🐄", layout="wide")
st.title("Livestock Adaptive Feed & Supply-Chain Optimizer")
st.caption("Integrated prototype: feed-mix optimizer + general supply-chain backorder model")

st.warning(
    "Research/demo limitation: the backorder model was trained on general product supply-chain data, "
    "not livestock-feed inventory. Its scores below are exploratory proxy scores only and must not be "
    "used as validated farm stockout probabilities or automatically change purchase quantities."
)

ingredients = pd.read_csv(ROOT / "data" / "feed_ingredients.csv")
suppliers = pd.read_csv(ROOT / "data" / "suppliers.csv")

with st.sidebar:
    st.header("Scenario inputs")
    st.warning("Ingredient values, prices, supplier stock and lead times are synthetic examples.")
    ration = st.number_input("Total ration quantity (kg/day)", 1.0, 100.0, 10.0, 0.5)
    protein = st.number_input("Minimum crude protein (kg/day)", 0.0, 20.0, 1.2, 0.1)
    energy = st.number_input("Minimum energy (MJ/day)", 0.0, 1000.0, 100.0, 5.0)
    lead = st.selectbox("Maximum supplier lead time", ["Any", 1, 2, 3, 4])
    budget_on = st.checkbox("Apply daily budget limit")
    budget = st.number_input("Budget per day", 1.0, 10000.0, 250.0, 10.0, disabled=not budget_on)
    st.subheader("Supply disruption")
    unavailable = st.multiselect("Unavailable suppliers", sorted(suppliers.supplier_id.unique()))
    price_multiplier = st.slider("Price multiplier", 1.0, 2.0, 1.0, 0.05)
    stock_multiplier = st.slider("Stock multiplier", 0.0, 1.0, 1.0, 0.1)

st.subheader("1. Feed ingredient and supplier data")
c1, c2 = st.columns(2)
with c1:
    st.dataframe(ingredients, use_container_width=True, hide_index=True)
with c2:
    st.dataframe(suppliers, use_container_width=True, hide_index=True)

effective = suppliers.copy()
effective["price_per_kg"] = effective.price_per_kg * price_multiplier
effective["stock_kg"] = effective.stock_kg * stock_multiplier
effective = effective[~effective.supplier_id.isin(unavailable)].copy()

st.subheader("2. Backorder-risk signal (exploratory proxy)")
st.write(
    "Enter estimated daily demand and in-transit stock per ingredient. The adapter maps these values into "
    "the general backorder model's feature schema. Several non-livestock features are set to neutral demo "
    "defaults, so scores are for workflow demonstration only—not validated livestock risk estimates."
)

default_demand = max(float(ration) / max(len(ingredients), 1), 1.0)
risk_rows = []
risk_inputs = []
for _, ing in ingredients.iterrows():
    ingredient = ing["ingredient"]
    available = float(effective.loc[effective["ingredient"] == ingredient, "stock_kg"].sum())
    offers = effective.loc[effective["ingredient"] == ingredient]
    lead_days = float(offers["lead_time_days"].min()) if not offers.empty else 8.0
    with st.expander(f"{ingredient} — inventory inputs", expanded=True):
        a, b, c = st.columns(3)
        daily_demand = a.number_input(
            f"Estimated daily demand (kg) — {ingredient}", min_value=0.0,
            value=float(default_demand), step=0.5, key=f"demand_{ingredient}"
        )
        transit = b.number_input(
            f"Stock in transit (kg) — {ingredient}", min_value=0.0,
            value=0.0, step=1.0, key=f"transit_{ingredient}"
        )
        min_bank_days = c.number_input(
            f"Safety stock target (days) — {ingredient}", min_value=0.0,
            value=3.0, step=0.5, key=f"bank_{ingredient}"
        )
    risk_inputs.append({
        "ingredient": ingredient, "current_stock_kg": available,
        "daily_demand_kg": daily_demand, "in_transit_kg": transit,
        "lead_time_days": lead_days, "safety_stock_days": min_bank_days
    })

model = joblib.load(MODEL_PATH)
model_features = [
    "national_inv", "lead_time", "in_transit_qty", "forecast_3_month",
    "forecast_6_month", "forecast_9_month", "sales_1_month", "sales_3_month",
    "sales_6_month", "sales_9_month", "min_bank", "potential_issue",
    "pieces_past_due", "perf_6_month_avg", "perf_12_month_avg", "local_bo_qty",
    "deck_risk", "oe_constraint", "ppap_risk", "stop_auto_buy", "rev_stop"
]
risk_df = pd.DataFrame(risk_inputs)
adapter_rows = []
for _, r in risk_df.iterrows():
    d = max(float(r["daily_demand_kg"]), 0.0)
    adapter_rows.append({
        "national_inv": float(r["current_stock_kg"]),
        "lead_time": float(r["lead_time_days"]),
        "in_transit_qty": float(r["in_transit_kg"]),
        "forecast_3_month": d * 90,
        "forecast_6_month": d * 180,
        "forecast_9_month": d * 270,
        "sales_1_month": d * 30,
        "sales_3_month": d * 90,
        "sales_6_month": d * 180,
        "sales_9_month": d * 270,
        "min_bank": d * float(r["safety_stock_days"]),
        "potential_issue": 0,
        "pieces_past_due": 0,
        "perf_6_month_avg": 0.98,
        "perf_12_month_avg": 0.98,
        "local_bo_qty": 0,
        "deck_risk": 0,
        "oe_constraint": 0,
        "ppap_risk": 0,
        "stop_auto_buy": 0,
        "rev_stop": 0
    })
model_input = pd.DataFrame(adapter_rows, columns=model_features)
risk_df["exploratory_backorder_score"] = model.predict_proba(model_input)[:, 1]
risk_df["proxy_flag_at_0_25"] = risk_df["exploratory_backorder_score"] >= 0.25
risk_df["days_of_stock_estimate"] = np.where(
    risk_df["daily_demand_kg"] > 0,
    risk_df["current_stock_kg"] / risk_df["daily_demand_kg"],
    np.inf
)
risk_df["inventory_review"] = np.where(
    risk_df["days_of_stock_estimate"] <= risk_df["lead_time_days"] + risk_df["safety_stock_days"],
    "Review inventory / lead time",
    "No rule-based warning"
)
st.dataframe(
    risk_df[[
        "ingredient", "current_stock_kg", "daily_demand_kg", "in_transit_kg",
        "lead_time_days", "days_of_stock_estimate", "exploratory_backorder_score",
        "proxy_flag_at_0_25", "inventory_review"
    ]].style.format({
        "current_stock_kg": "{:.1f}", "daily_demand_kg": "{:.1f}",
        "in_transit_kg": "{:.1f}", "lead_time_days": "{:.1f}",
        "days_of_stock_estimate": "{:.1f}", "exploratory_backorder_score": "{:.1%}"
    }),
    use_container_width=True, hide_index=True
)
st.caption(
    "The model score is a general supply-chain model applied through a proxy feature mapping. "
    "The days-of-stock rule is transparent arithmetic. Neither is validated on livestock-feed stockout labels."
)

st.subheader("3. Cost-minimizing feed plan")
config = OptimizationConfig(
    total_ration_kg=ration,
    min_crude_protein_kg=protein,
    min_energy_mj=energy,
    max_lead_time_days=None if lead == "Any" else int(lead),
    budget_limit=budget if budget_on else None
)
result = optimize_feed_plan(ingredients, effective, config)
if result["success"]:
    m = result["metrics"]
    a, b, c, d = st.columns(4)
    a.metric("Estimated cost/day", f"{m['total_cost']:.2f}")
    b.metric("Ration quantity", f"{m['total_quantity_kg']:.2f} kg")
    c.metric("Crude protein", f"{m['crude_protein_kg']:.2f} kg")
    d.metric("Energy", f"{m['energy_mj']:.1f} MJ")
    st.success(result["message"])
    st.dataframe(result["plan"].round(3), use_container_width=True, hide_index=True)
    st.write({
        "Protein minimum met": m["protein_constraint_met"],
        "Energy minimum met": m["energy_constraint_met"],
        "Budget": "Not applied" if not budget_on else budget
    })
else:
    st.error(result["message"])

st.info(
    "The risk model currently flags ingredients for review but does not alter optimization quantities. "
    "This prevents unvalidated proxy scores from automatically controlling procurement."
)
with st.expander("Integration architecture and limitations"):
    st.markdown("""
    - **Backorder model:** tuned Random Forest trained on general product backorder data.
    - **Feature adapter:** maps estimated feed stock, demand, lead time and transit quantities into the model's expected schema; non-matching fields use demo defaults.
    - **Inventory rule:** days of stock is compared with lead time plus a user-selected safety-stock buffer.
    - **Optimizer:** minimizes cost subject to the configured ration, nutrient, stock, lead-time and budget constraints.
    - **Not yet integrated:** animal Digital Twin, disease model and physical IoT ingestion.
    - **Before deployment:** replace synthetic ingredient/supplier data, source verified cattle nutrition values, and train/validate a risk model on real feed inventory histories.
    """)
