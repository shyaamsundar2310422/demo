from dataclasses import dataclass
from typing import Optional
import pandas as pd
from scipy.optimize import linprog

@dataclass
class OptimizationConfig:
    total_ration_kg: float = 10.0
    min_crude_protein_kg: float = 1.2
    min_energy_mj: float = 100.0
    max_lead_time_days: Optional[int] = None
    budget_limit: Optional[float] = None
    unavailable_supplier_ids: tuple[str, ...] = ()


def optimize_feed_plan(ingredients: pd.DataFrame, suppliers: pd.DataFrame, config: OptimizationConfig) -> dict:
    """Minimize cost of a daily ingredient mix subject to nutrient, stock and optional constraints.

    Included CSV data and default nutrient constraints are synthetic demonstrations, not feeding advice.
    """
    ingredient_cols = {"ingredient", "crude_protein_fraction", "energy_mj_per_kg"}
    supplier_cols = {"supplier_id", "supplier_name", "region", "ingredient", "price_per_kg", "stock_kg", "lead_time_days"}
    if not ingredient_cols.issubset(ingredients.columns) or not supplier_cols.issubset(suppliers.columns):
        raise ValueError("Input data is missing required columns")
    if config.total_ration_kg <= 0 or config.min_crude_protein_kg < 0 or config.min_energy_mj < 0:
        raise ValueError("Ration must be positive; nutrient minimums cannot be negative")
    data = suppliers.merge(ingredients, on="ingredient", how="inner")
    data = data[~data.supplier_id.astype(str).isin(config.unavailable_supplier_ids)].copy()
    if config.max_lead_time_days is not None:
        data = data[data.lead_time_days <= config.max_lead_time_days].copy()
    data = data[data.stock_kg > 0].reset_index(drop=True)
    if data.empty:
        return {"success": False, "message": "No eligible supplier offers remain after filters.", "plan": pd.DataFrame()}
    c = data.price_per_kg.astype(float).to_numpy()
    cp = data.crude_protein_fraction.astype(float).to_numpy()
    energy = data.energy_mj_per_kg.astype(float).to_numpy()
    stock = data.stock_kg.astype(float).to_numpy()
    A_ub = [-cp, -energy]
    b_ub = [-config.min_crude_protein_kg, -config.min_energy_mj]
    if config.budget_limit is not None:
        A_ub.append(c)
        b_ub.append(config.budget_limit)
    result = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=[[1.0] * len(data)], b_eq=[config.total_ration_kg], bounds=[(0, float(s)) for s in stock], method="highs")
    if not result.success:
        return {"success": False, "message": "No feasible plan found. Review nutrient requirements, ration quantity, budget, stock and supplier filters. Solver: " + result.message, "plan": pd.DataFrame()}
    data["quantity_kg"] = result.x
    data["line_cost"] = data.quantity_kg * data.price_per_kg
    plan = data[data.quantity_kg > 1e-6][["ingredient", "supplier_id", "supplier_name", "region", "quantity_kg", "price_per_kg", "line_cost", "lead_time_days"]].copy()
    total_cp = float((data.quantity_kg * data.crude_protein_fraction).sum())
    total_energy = float((data.quantity_kg * data.energy_mj_per_kg).sum())
    return {"success": True, "message": "Feasible lowest-cost plan found for the supplied demo data and constraints.", "plan": plan.sort_values(["ingredient", "supplier_id"]).reset_index(drop=True), "metrics": {"total_quantity_kg": float(data.quantity_kg.sum()), "crude_protein_kg": total_cp, "energy_mj": total_energy, "total_cost": float(data.line_cost.sum()), "protein_constraint_met": total_cp + 1e-7 >= config.min_crude_protein_kg, "energy_constraint_met": total_energy + 1e-7 >= config.min_energy_mj}}
