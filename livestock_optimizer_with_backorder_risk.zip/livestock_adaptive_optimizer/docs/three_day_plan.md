# Three-day integration checklist

## Day 1: core model
- [x] Linear programming feed formulation with supplier-aware procurement.
- [x] Stock and lead-time constraints, optional budget.
- [x] Price and stock shocks and supplier-outage scenarios.
- [x] Streamlit interface.
- [ ] Replace synthetic inputs with sourced/cited data.
- [ ] Export scenario results for comparison.

## Day 2: livestock management integration
- [ ] Add animal profiles and historical Digital Twin state (SQLite is enough for prototype).
- [ ] Add health observation records, separating measured, manually entered and AI-estimated data.
- [ ] Integrate existing classifier behind an adapter; prediction is not a diagnosis.
- [ ] Add sensor ingestion interface; label simulated data if no hardware is connected.
- [ ] Trigger re-optimization after relevant data changes.

## Day 3: evaluation and delivery
- [ ] Compare baseline vs adaptive scenarios.
- [ ] Report cost, feasibility, constraint satisfaction and resilience to disruption.
- [ ] Test infeasible cases and validation errors.
- [ ] Prepare architecture, methodology, results and demo script.

Synthetic data is acceptable for testing model mechanics, but must be clearly labelled in the report and presentation.
