# Dairy cow dry matter intake for multiverse analysis and Bradley-Terry modeling

<https://doi.org/10.5061/dryad.sn02v6xbd>

This dataset originates from a study conducted at the William H. Miner Agricultural Research Institute (Chazy, NY) during summer 2021. Feed from two bunks (that is, two ensiling conditions) and from two aerobic exposure times (0 and 48 hours) were considered, for a total of four feed types. The four feed types were offered to twelve heifers in a pairwise fashion (4 types = 6 pairwise comparisons). The observations consist of the dry matter intake of each heifer by feed type and day. This dataset is being employed as a testbed for an statistical analysis approach consisting of multiverse analysis and Bradley-Terry modeling.

## Description of the data and file structure

The dataset consists of a single CSV file (dry_matter_intake_for_multiverse_and_bt.csv). The unit of observation is a feed offered on a particular day to a particular cow. That is, each row is "half" of one pairwise comparison. There are 144 observations (12 heifers x 2 feeds/day x 6 days). The file contains nine columns:

date - date in M/D/YYYY format

cow.id - cow ID

trmt - feed type (A0 = bunk A, 0 hours aerobic exposure, A48 = bunk A, 48 hours aerobic exposure, B0 = bunk B, 0 hours aerobic exposure, B48 = bunk B, 48 hours aerobic exposure)

bunk - bunk the feed was taken from (A or B)

time - aerobic exposure time, in hours (0 or 48 hours)

pos - position in which the feed was offered to the heifer (L=left, R=right)

feedout.t.C - temperature (in degrees Celsius) of the feed at time of feeding

dmi.kg.30mins - dry matter intake (in kg) after 30 minutes

dmi.kg.3h - dry matter intake (in kg) after 3 hours

No observations are missing.

## Code/Software

Self-documented code for applying the proposed methodology to the dataset is in "multiverse_and_bt_for_palatability.R".
