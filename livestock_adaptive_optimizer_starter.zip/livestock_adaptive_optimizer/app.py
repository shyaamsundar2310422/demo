from pathlib import Path
import pandas as pd
import streamlit as st
from src.optimizer import OptimizationConfig, optimize_feed_plan

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="Livestock Adaptive Optimizer", page_icon="🐄", layout="wide")
st.title("Livestock Adaptive Feed & Supply-Chain Optimizer")
st.caption("Starter prototype — synthetic demo data only; not a real-animal feeding recommendation")
ingredients = pd.read_csv(ROOT / "data" / "feed_ingredients.csv")
suppliers = pd.read_csv(ROOT / "data" / "suppliers.csv")
with st.sidebar:
    st.header("Scenario inputs")
    st.warning("Ingredient values, prices, supplier stock and lead times are synthetic examples.")
    ration = st.number_input("Total ration quantity (kg/day)", 1.0, 100.0, 10.0, 0.5)
    protein = st.number_input("Minimum crude protein (kg/day)", 0.0, 20.0, 1.2, 0.1)
    energy = st.number_input("Minimum energy (MJ/day)", 0.0, 1000.0, 100.0, 5.0)
    lead = st.selectbox("Maximum supplier lead time", ["Any", 1, 2, 3, 4])
    budget_on = st.checkbox("Apply daily budget limit")
    budget = st.number_input("Budget per day", 1.0, 10000.0, 250.0, 10.0, disabled=not budget_on)
    st.subheader("Supply disruption")
    unavailable = st.multiselect("Unavailable suppliers", sorted(suppliers.supplier_id.unique()))
    price_multiplier = st.slider("Price multiplier", 1.0, 2.0, 1.0, 0.05)
    stock_multiplier = st.slider("Stock multiplier", 0.0, 1.0, 1.0, 0.1)
col1, col2 = st.columns(2)
with col1:
    st.subheader("Feed ingredient data")
    st.dataframe(ingredients, use_container_width=True, hide_index=True)
with col2:
    st.subheader("Supplier offers")
    st.dataframe(suppliers, use_container_width=True, hide_index=True)
effective = suppliers.copy()
effective["price_per_kg"] = effective.price_per_kg * price_multiplier
effective["stock_kg"] = effective.stock_kg * stock_multiplier
effective = effective[~effective.supplier_id.isin(unavailable)].copy()
config = OptimizationConfig(total_ration_kg=ration, min_crude_protein_kg=protein, min_energy_mj=energy, max_lead_time_days=None if lead == "Any" else int(lead), budget_limit=budget if budget_on else None)
st.divider()
st.subheader("Optimization result")
result = optimize_feed_plan(ingredients, effective, config)
if result["success"]:
    m = result["metrics"]
    a,b,c,d = st.columns(4)
    a.metric("Estimated cost/day", f"{m['total_cost']:.2f}")
    b.metric("Ration quantity", f"{m['total_quantity_kg']:.2f} kg")
    c.metric("Crude protein", f"{m['crude_protein_kg']:.2f} kg")
    d.metric("Energy", f"{m['energy_mj']:.1f} MJ")
    st.success(result["message"])
    st.dataframe(result["plan"].round(3), use_container_width=True, hide_index=True)
    st.write({"Protein minimum met": m["protein_constraint_met"], "Energy minimum met": m["energy_constraint_met"], "Budget": "Not applied" if not budget_on else budget})
else:
    st.error(result["message"])
st.info("Before making animal-facing recommendations, replace the illustrative nutrient constraints and ingredient data with verified values for a defined cattle category and obtain qualified review.")
with st.expander("What this prototype does and does not do"):
    st.markdown("The optimizer connects supplier offers (price, stock, region, lead time) with ingredient nutrient composition. It minimizes cost while meeting configured constraints. Change prices, stock, supplier availability or lead-time limits to explore disruptions. The Digital Twin, disease classifier and physical IoT integration are not connected yet.")
