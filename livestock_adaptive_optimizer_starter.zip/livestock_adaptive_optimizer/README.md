# Livestock Adaptive Feed & Supply-Chain Optimizer

A starter prototype for the project's first integrated model: nutrition constraints + supplier prices, stock, region and lead times. It minimizes procurement cost, handles infeasible scenarios, and supports price/stock/supplier disruption experiments.

## Run it

Python 3.10+ recommended:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Critical data disclaimer
The included ingredient nutrient values, default constraints, prices, stocks and delivery times are **synthetic demonstration data**. They are not live supplier data and the default ration constraints are not animal-feeding advice. Replace them with cited, verified data for a defined cattle category and have the requirements reviewed by a qualified animal nutrition professional before using the system for real animals.

## Model
Decision variable: kg/day of each ingredient purchased from each supplier offer.
Objective: minimize sum(quantity × effective unit price).
Constraints: total ration mass, minimum crude protein, minimum energy, per-offer stock, optional maximum supplier lead time, and optional budget.

## Included
- `app.py`: Streamlit interface and scenario runner.
- `src/optimizer.py`: linear programming model using SciPy.
- `data/`: synthetic example CSVs.
- `tests/`: basic model tests.

## Next steps
1. Source and cite real feed composition and animal nutrition requirements.
2. Add a Digital Twin record model and history.
3. Integrate the existing cattle image classifier as an AI estimate, not a diagnosis.
4. Add actual sensor ingestion or clearly labelled simulated sensor data.
5. Evaluate baseline vs adaptive decisions under supplier outages, price shocks and stock reductions.
