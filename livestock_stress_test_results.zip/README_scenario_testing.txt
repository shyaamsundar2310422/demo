Livestock feed supply-chain scenario testing prototype
Scenarios: baseline, +20% synthetic ingredient price shock, +3 day supplier delay, combined.
Inventory and prices are synthetic/illustrative and are not real farm forecasts or validated cattle nutrition advice.
The cost metric estimates 30-day consumed feed at the scenario unit prices; it is not a procurement cash-flow total.
Stockout metrics depend on the stated starting stocks, demands, order quantities, reorder points and delivery delays.
Validate ingredient mappings, units, local prices and nutritional constraints with appropriate sources and experts before real-world use.
